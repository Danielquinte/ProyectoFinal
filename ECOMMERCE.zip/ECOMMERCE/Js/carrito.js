// Obtener el carrito de compras almacenado en el localStorage (si existe) 
let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

// Referencia a la tabla donde se mostrarán los productos del carrito
const productosCarritoTable = document.getElementById('productos-carrito').querySelector('tbody');

// Función para actualizar la tabla del carrito y mostrar el total
function actualizarCarrito() {
    // Limpiar la tabla antes de mostrar los productos
    productosCarritoTable.innerHTML = '';
    let total = 0;

    // Agrupar productos por nombre y contar las cantidades
    const productosAgrupados = carrito.reduce((acc, producto) => {
        const encontrado = acc.find(p => p.nombre === producto.nombre);
        if (encontrado) {
            encontrado.cantidad += 1; // Aumentar la cantidad
        } else {
            acc.push({...producto, cantidad: 1}); // Agregar un nuevo producto con cantidad 1
        }
        return acc;
    }, []);

    // Iterar sobre los productos agrupados y agregarlos a la tabla
    productosAgrupados.forEach((producto, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><img src="${producto.imagen}" alt="${producto.nombre}" width="50"></td>
            <td>${producto.nombre}</td>
            <td>${producto.precio}</td>
            <td>${producto.cantidad}</td>
            <td><button class="btn btn-danger btn-sm" onclick="eliminarProducto(${index})">Eliminar</button></td>
        `;
        productosCarritoTable.appendChild(row);
        // Sumar el precio total considerando la cantidad
        total += parseFloat(producto.precio.replace('$', '').replace(',', '')) * producto.cantidad;
    });

    // Mostrar el total en la página
    document.getElementById('total-carrito').textContent = `Total: $${total.toFixed(2)}`;
}

// Función para eliminar un producto del carrito
function eliminarProducto(index) {
    // Eliminar el producto de la lista (array)
    const producto = carrito[index];
    if (producto.cantidad > 1) {
        // Si hay más de una cantidad, solo reducir la cantidad
        producto.cantidad--;
    } else {
        // Si solo hay una cantidad, eliminar el producto completamente
        carrito.splice(index, 1);
    }
    // Guardar el carrito actualizado en el localStorage
    localStorage.setItem('carrito', JSON.stringify(carrito));
    // Actualizar la vista del carrito
    actualizarCarrito();
}

// Función para mostrar el formulario de pago
function mostrarFormularioPago() {
    if (carrito.length === 0) {
        // Si el carrito está vacío, mostrar un mensaje de alerta
        alert('El carrito está vacío. Agrega productos antes de proceder al pago.');
        return;
    }

    // Ocultar la sección del carrito y mostrar el formulario de pago
    document.querySelector('section').style.display = 'none';
    document.getElementById('formulario-pago').style.display = 'block';
}

// Función para enviar el correo con los detalles del pago (usando EmailJS)
function enviarPago(event) {
    // Prevenir el comportamiento predeterminado del formulario (enviar el formulario)
    event.preventDefault();

    // Obtener los datos del formulario
    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;
    const direccion = document.getElementById('direccion').value;
    const metodoPago = document.getElementById('metodoPago').value;

    // Crear el contenido del correo
    const contenidoCorreo = `  
        Nombre: ${nombre}
        Correo: ${correo}
        Dirección: ${direccion}
        Método de Pago: ${metodoPago}
        Productos en el carrito: ${carrito.map(producto => `${producto.nombre} x${producto.cantidad} - ${producto.precio}`).join(', ')}
    `;

    // Configurar el envío del correo usando EmailJS
    emailjs.send('service_id', 'template_id', {
        to_email: 'tu-correo@example.com',
        subject: 'Compra Realizada',
        message: contenidoCorreo
    }).then(response => {
        alert('Compra realizada con éxito');
        // Vaciar el carrito después de la compra
        localStorage.removeItem('carrito');
        // Volver a mostrar el carrito vacío
        actualizarCarrito();
        // Ocultar el formulario de pago y mostrar el carrito
        document.getElementById('formulario-pago').style.display = 'none';
        document.querySelector('section').style.display = 'block';
    }).catch(error => {
        console.error('Error al enviar el correo: ', error);
        alert('En un momento te llegara al correo una confirmacion');
    });
}

// Llamar a la función para actualizar el carrito cuando la página cargue
document.addEventListener('DOMContentLoaded', actualizarCarrito);
