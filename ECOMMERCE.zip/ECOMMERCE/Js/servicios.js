
    // Script que hace el desplazamiento suave al footer al hacer clic en el enlace de contacto en la barra de navegación
    document.querySelector('a[href="#footer"]').addEventListener('click', function(event) {
        event.preventDefault(); // Prevenir el comportamiento por defecto del enlace
        document.querySelector('#footer').scrollIntoView({
            behavior: 'smooth' // Realiza el desplazamiento suave
        });
    });