Proyecto Ecommerce

Este proyecto es un sitio web de ecommerce diseñado para ofrecer productos y servicios en línea, integrando funcionalidades de navegación, carrito de compras, servicios, contacto y más. El sitio utiliza tecnologías web modernas como HTML, CSS, JavaScript y Bootstrap para asegurar una experiencia de usuario fluida y responsive.

 Características principales

1. Página de inicio (index.html):
   - Presenta el logo y un menú de navegación.
   - Sección destacada con productos y servicios.
   - Estilo responsive gracias a Bootstrap para adaptarse a dispositivos móviles.

2. Página de productos (productos.html):
   - Muestra una lista de productos disponibles.
   - Opción de agregar productos al carrito de compras.
   - Interfaz interactiva con botones y efectos hover en las tarjetas de productos.

3. Página de servicios (servicios.html):
   - Presenta los servicios que ofrece el ecommerce.
   - Descripción de cada servicio en una tarjeta con imagen y texto.
   - Sección de testimonios de clientes que describen sus experiencias.

4. Carrito de compras:
   - Permite ver los productos seleccionados y realizar modificaciones en la cantidad.
   - Muestra un resumen de la compra antes de proceder con el pago.

5. Footer (pie de página):
   - Contiene información de contacto y un enlace a la sección de servicios.

 Requisitos para ejecutar el proyecto

Para ejecutar el proyecto en tu máquina local, asegúrate de tener instalado un servidor web básico (por ejemplo, **XAMPP**, **MAMP**, **VS Code Live Server**) o simplemente abrir los archivos en tu navegador de forma local.

1. Clona o descarga el proyecto en tu máquina local.
2. Navega a la carpeta donde descargaste el proyecto.
3. Abre el archivo `index.html` en tu navegador preferido.
4. Asegúrate de que los archivos `servicios.html`, `productos.html`, `css/index.css`, `js/servicios.js`, etc., estén en las rutas adecuadas dentro de la estructura de carpetas.

