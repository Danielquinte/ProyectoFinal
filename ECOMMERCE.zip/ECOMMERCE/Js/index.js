// Mostrar y ocultar el carrito
document.getElementById('cart-icon').addEventListener('click', function() {
    const carrito = document.getElementById('carrito');
    carrito.style.display = carrito.style.display === 'none' || carrito.style.display === '' ? 'block' : 'none';
});

// Agregar evento para cerrar el carrito
document.getElementById('cerrar-carrito').addEventListener('click', function() {
    const carrito = document.getElementById('carrito');
    carrito.style.display = 'none';
});

// Función para actualizar el carrito visualmente
function actualizarCarrito() {
    const listaCarrito = document.getElementById('lista-carrito').querySelector('tbody');
    listaCarrito.innerHTML = ''; // Limpiar la tabla de productos
    const carrito = JSON.parse(localStorage.getItem('carrito')) || []; // Obtener carrito desde el localStorage
    let total = 0;

    // Actualizar contador de productos en el ícono del carrito
    const cartCount = document.getElementById('cart-count');
    if (carrito.length > 0) {
        cartCount.style.display = 'block';
        cartCount.textContent = carrito.length; // Mostrar la cantidad de productos
    } else {
        cartCount.style.display = 'none'; // Ocultar si el carrito está vacío
    }

    carrito.forEach(producto => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><img src="${producto.imagen}" alt="${producto.nombre}" width="30"></td>
            <td>${producto.nombre}</td>
            <td>$${producto.precio}</td>
        `;
        listaCarrito.appendChild(row); // Agregar fila a la tabla
        total += parseFloat(producto.precio); // Sumar el precio al total
    });

    // Mostrar el total en la página
    document.getElementById('total-carrito').textContent = `Total: $${total.toFixed(2)}`;
}

// Agregar productos al carrito al hacer clic en el botón "Agregar"
document.querySelectorAll('.add-to-cart').forEach(boton => {
    boton.addEventListener('click', function(e) {
        e.preventDefault();
        const card = e.target.closest('.card');
        const producto = {
            nombre: card.getAttribute('data-nombre'),
            precio: card.getAttribute('data-precio'),
            imagen: card.getAttribute('data-imagen')
        };

        // Guardar el producto en el carrito del localStorage
        const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
        carrito.push(producto);
        localStorage.setItem('carrito', JSON.stringify(carrito));

        actualizarCarrito(); // Actualizar el carrito visualmente
    });
});

// Vaciar el carrito
document.getElementById('vaciar-carrito').addEventListener('click', function() {
    localStorage.removeItem('carrito'); // Eliminar el carrito del localStorage
    actualizarCarrito(); // Actualizar la vista del carrito
});

// Inicializar el carrito al cargar la página
window.onload = actualizarCarrito;
